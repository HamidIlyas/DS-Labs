/*
I have been asked to write global functions that work with a linked list of Nodes.
Each Node contains an integer value and a pointer to the next Node. The functions
should allow me to copy the list, free memory, insert a new Node, remove a Node,
and display the list. The idea is to practice linked list operations.

I will create each function one by one:
- For copy: I will start from the head and create new Nodes with the same values,
  linking them together. Example: (A -> B -> C ->) becomes a new (A -> B -> C ->).
- For freeMemory: I will move through the list and delete each Node one by one
  until the list is empty.
- For insert: I will move to the given position and connect a new Node there.
  Example: (A -> B -> C ->), insert D at pos 1 gives (A -> D -> B -> C ->).
- For remove: I will move to the given position, disconnect that Node, delete it,
  and return its value. Example: (A -> B -> C ->), remove at pos 1 gives (A -> C ->).
- For display: I will print each Node�s data in order until the end.

- The display function will be reused often to show the list after each operation.
- After insert, I will call display to show the new list.
- After remove, I will call display to show the updated list.
- After copy, I will call display to show the copied list.
This way I can see the progression clearly:
Original: (10 -> 20 -> 30 ->)
Insert 15 at pos 1: (10 -> 15 -> 20 -> 30 ->)
Remove at pos 2: (10 -> 15 -> 30 ->)
Copy: (10 -> 15 -> 30 ->)
*/

#include <iostream>
#include "node.h"
using namespace std;

// 1. Copy the chain of nodes
Node* copy(Node* head)
{
    if (!head)
    {
        return nullptr;
    }
    Node* newHead = new Node
    {
        head->data, nullptr 
    };
    Node* currNew = newHead;
    Node* currOld = head->next;
    while (currOld) 
    {
        currNew->next = new Node { currOld->data, nullptr };
        currNew = currNew->next;
        currOld = currOld->next;
    }
    return newHead;
}

// 2. Free memory
void freeMemory(Node* head) 
{
    while (head) {
        Node* temp = head;
        head = head->next;
        delete temp;
    }
}

// 3. Insert at position (0-based)
void insert(Node* head, const int& value, const int& pos)
{
    Node* newNode = new Node{ value, nullptr };
    Node* curr = head;
    for (int i = 0; curr && i < pos - 1; i++) {
        curr = curr->next;
    }
    if (curr) {
        newNode->next = curr->next;
        curr->next = newNode;
    }
}

// 4. Remove at position (0-based)
int remove(Node* head, const int& pos) 
{
    if (!head) return -1;
    if (pos == 0) {
        int val = head->data;
        // Caller must handle head reassignment if removing first node
        return val;
    }
    Node* curr = head;
    for (int i = 0; curr->next && i < pos - 1; i++) 
    
    {
        curr = curr->next;
    }
    if (curr->next) 
    {
        Node* temp = curr->next;
        int val = temp->data;
        curr->next = temp->next;
        delete temp;
        return val;
    }
    return -1;
}

// 5. Display nodes
void display(Node* head) 
{
    Node* curr = head;
    while (curr) 
    {
        cout << curr->data << " -> ";
        curr = curr->next;
    }
    cout << "NULL" << endl;
}

// Main function to test
int main()
{
    Node* head = new Node{ 10, nullptr };
    head->next = new Node{ 20, nullptr };
    head->next->next = new Node{ 30, nullptr };

    cout << "Original list: ";
    display(head);

    insert(head, 15, 1);
    cout << "After inserting 15 at pos 1: ";
    display(head);

    int removed = remove(head, 2);
    cout << "Removed value at pos 2: " << removed << endl;
    display(head);

    Node* copied = copy(head);
    cout << "Copied list: ";
    display(copied);

    freeMemory(head);
    freeMemory(copied);

    return 0;
}
