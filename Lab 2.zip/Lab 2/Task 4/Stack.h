#ifndef STACK_H
#define STACK_H

#include <string>
using namespace std;

const int MAX_SIZE = 100; // maximum 100 words

class Stack
{
private:
    string arr[MAX_SIZE];
    int top;

public:
    Stack(int size = MAX_SIZE)
    {
        top = -1;
    }

    void push(string value)
    {
        if (top < MAX_SIZE - 1)
        {
            top++;
            arr[top] = value;
        }
    }

    string pop()
    {
        if (top >= 0)
            return arr[top--];
        return "";
    }

    string peek(int index)
    {
        return arr[index];
    }

    void set(int index, string value)
    {
        arr[index] = value;
    }

    int getSize()
    {
        return top + 1;
    }

    void setSize(int s)
    {
        top = s - 1;
    }
};

#endif