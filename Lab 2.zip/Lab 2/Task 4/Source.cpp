#include <iostream>
#include <fstream>
#include <string>
using namespace std;

#include "Stack.h"
#include "MyStack.h"

// 1?? Read words from file
void readFile(Stack* s, const string& filename)
{
    ifstream fin(filename);
    string word;

    while (fin >> word)
    {
        s->push(word);
    }

    fin.close();
}

// 2?? Display stack
void display(Stack* s)
{
    for (int i = 0; i < s->getSize(); i++)
        cout << s->peek(i) << " ";
    cout << endl;
}

// 3?? Copy stack in reverse
void reverseCopy(Stack* src, Stack* dst)
{
    for (int i = src->getSize() - 1; i >= 0; i--)
        dst->push(src->peek(i));
}

// 4?? Remove duplicates (keep first occurrence)
void removeDuplicates(Stack* s)
{
    Stack temp; // temporary stack
    for (int i = 0; i < s->getSize(); i++)
    {
        string word = s->peek(i);
        bool duplicate = false;
        for (int j = 0; j < temp.getSize(); j++)
        {
            if (temp.peek(j) == word)
            {
                duplicate = true;
                break;
            }
        }
        if (!duplicate)
            temp.push(word);
    }

    // copy temp back to original stack
    for (int i = 0; i < temp.getSize(); i++)
        s->set(i, temp.peek(i));

    s->setSize(temp.getSize());
}

// 5?? Count frequency
void countFrequency(Stack* s)
{
    Stack words;
    Stack freq;

    for (int i = 0; i < s->getSize(); i++)
    {
        string w = s->peek(i);
        int count = 0;

        for (int j = 0; j < s->getSize(); j++)
        {
            if (s->peek(j) == w)
                count++;
        }

        // check if already counted
        bool already = false;
        for (int k = 0; k < words.getSize(); k++)
        {
            if (words.peek(k) == w)
            {
                already = true;
                break;
            }
        }

        if (!already)
        {
            words.push(w);
            freq.push(to_string(count));
        }
    }

    // display word with frequency
    for (int i = 0; i < words.getSize(); i++)
    {
        cout << words.peek(i) << " -> " << freq.peek(i) << endl;
    }
}

int main()
{
    Stack* S = new Stack(MAX_SIZE);

    readFile(S, "para.txt");

    cout << "Original Stack: ";
    display(S);

    Stack* rev = new Stack(MAX_SIZE);
    reverseCopy(S, rev);
    cout << "Reversed Stack: ";
    display(rev);

    removeDuplicates(rev);
    cout << "Stack after removing duplicates: ";
    display(rev);

    cout << "Frequency of words: " << endl;
    countFrequency(S);

    return 0;
}