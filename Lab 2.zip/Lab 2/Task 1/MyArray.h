#ifndef MYARRAY_H
#define MYARRAY_H

#include <iostream>
#include "AbstractArray.h"
using namespace std;

void read(AbstractArray*, istream&, int);
void display(AbstractArray*, ostream&);
void copy(AbstractArray*, AbstractArray*);
void insert(AbstractArray*, AbstractArray*, int);
void shiftLeft(AbstractArray*, int);
void shiftRight(AbstractArray*, int);
void stats(AbstractArray*, int&, float&);

#endif