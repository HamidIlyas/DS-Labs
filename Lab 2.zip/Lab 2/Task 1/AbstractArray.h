#pragma once
#ifndef ABSTRACTARRAY_H
#define ABSTRACTARRAY_H

const int MAX_SIZE = 10;

class AbstractArray
{
private:
    int arr[MAX_SIZE];
    int size;

public:
    AbstractArray(int max = MAX_SIZE)
    {
        size = 0;
    }

    void add(int value)
    {
        if (size < MAX_SIZE)
        {
            arr[size] = value;
            size++;
        }
    }

    int get(int index)
    {
        return arr[index];
    }

    void set(int index, int value)
    {
        arr[index] = value;
    }

    int getSize()
    {
        return size;
    }

    void setSize(int s)
    {
        size = s;
    }
};

#endif