#include <iostream>
using namespace std;

#include "Stack.h"


void read(Stack* s, int n)
{
    int value;

    for (int i = 0; i < n; i++)
    {
        cin >> value;
        s->push(value);
    }
}


void display(Stack* s)
{
    for (int i = 0; i < s->getSize(); i++)
    {
        cout << s->peek(i) << " ";
    }
    cout << endl;
}


bool isPrime(int n)
{
    if (n <= 1) return false;

    for (int i = 2; i < n; i++)
    {
        if (n % i == 0)
            return false;
    }

    return true;
}


bool isPerfectSquare(int n)
{
    for (int i = 1; i * i <= n; i++)
    {
        if (i * i == n)
            return true;
    }

    return false;
}


bool isPalindromeNumber(int n)
{
    int original = n;
    int rev = 0;

    while (n > 0)
    {
        rev = rev * 10 + n % 10;
        n = n / 10;
    }

    return original == rev;
}


bool isStackPalindrome(Stack* s)
{
    int size = s->getSize();

    for (int i = 0; i < size / 2; i++)
    {
        if (s->peek(i) != s->peek(size - 1 - i))
            return false;
    }

    return true;
}


int main()
{
    Stack* A = new Stack(MAX_SIZE);

    cout << "Enter 10 numbers:" << endl;

    read(A, 10);

    cout << "Stack Values: ";
    display(A);

    for (int i = 0; i < A->getSize(); i++)
    {
        int val = A->peek(i);

        cout << "Number " << val << ": ";

        if (isPrime(val))
            cout << "Prime ";

        if (isPerfectSquare(val))
            cout << "PerfectSquare ";

        if (isPalindromeNumber(val))
            cout << "Palindrome ";

        cout << endl;
    }

    if (isStackPalindrome(A))
        cout << "Stack forms a Palindrome" << endl;
    else
        cout << "Stack does NOT form a Palindrome" << endl;

    return 0;
}