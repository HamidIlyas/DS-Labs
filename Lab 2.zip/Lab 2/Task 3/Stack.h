#pragma once
#ifndef STACK_H
#define STACK_H

const int MAX_SIZE = 10;

class Stack
{
private:
    int arr[MAX_SIZE];
    int top;

public:
    Stack(int size = MAX_SIZE)
    {
        top = -1;
    }

    void push(int value)
    {
        if (top < MAX_SIZE - 1)
        {
            top++;
            arr[top] = value;
        }
    }

    int pop()
    {
        if (top >= 0)
            return arr[top--];
        return -1;
    }

    int peek(int index)
    {
        return arr[index];
    }

    int getSize()
    {
        return top + 1;
    }
};

#endif