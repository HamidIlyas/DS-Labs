#pragma once
#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node* next;
};

class LinkedList
{
protected:
    Node* first;
    Node* last;

public:
    LinkedList() { first = nullptr; last = nullptr; };


    LinkedList(const LinkedList& other)
    {
        if (other.first == nullptr)
        {
            first = last = nullptr;
            return;
        }

        // Copy first node
        first = new Node;
        first->data = other.first->data;
        first->next = nullptr;

        Node* current = first;
        Node* temp = other.first->next;

        // Copy rest
        while (temp != nullptr)
        {
            Node* newNode = new Node;
            newNode->data = temp->data;
            newNode->next = nullptr;

            current->next = newNode;
            current = newNode;
            temp = temp->next;
        }

        last = current;
    }

    virtual ~LinkedList();

    virtual void insertAtLast(int) = 0;
    virtual void insertAtFirst(int) = 0;
    virtual int removeFromFirst() = 0;
    virtual int removeFromLast() = 0;
    virtual bool isEmpty() = 0;
    virtual void display() = 0;
};

LinkedList::~LinkedList()
{
    Node* temp = first;

    while (temp != nullptr)
    {
        Node* nextNode = temp->next;
        delete temp;
        temp = nextNode;
    }

    first = nullptr;
    last = nullptr;
}