﻿#include <iostream>
#include "LinkedList.h"
#include "myLinkedList.h"
using namespace std;

/*
1. What I understand about the task:

Is task mein humein Linked List ke Destructor aur Copy Constructor ko theek karna hai.

Destructor ka kaam hai ke jab list khatam ho ya object delete ho,
to poori list ki memory free ho jaye.

Copy Constructor ka kaam hai ke ek list ki exact copy banani hai,
lekin dono lists alag hon (memory share na karein).

Agar yeh sahi na hon:
- Destructor memory leak karega
- Copy Constructor galat copy karega


2. How I will solve the task:

Destructor:
List: (1 → 2 → 3 →)

Step:
Delete 1
Delete 2
Delete 3

End → empty

Copy Constructor:
Original:
(1 → 2 → 3 →)

New list banayenge:

Step 1:
(1 →)

Step 2:
(1 → 2 →)

Step 3:
(1 → 2 → 3 →)


3. Functions reused and explanation:

Traversal use kiya:
first se start → next pe move

Copy process:
Original: (10 → 20 → 30 →)

After copy:
New: (10 → 20 → 30 →)

Remove example:
(10 → 20 → 30 →)
removeFromFirst()
(20 → 30 →)

removeFromLast()
(20 →)


4. What I learned:

- Linked List manually manage karni hoti hai
- Destructor bohat important hota hai
- Copy constructor deep copy karta hai


5. Skills developed:

- Memory handling
- Linked List banana aur delete karna
- Safe coding

Ab main:
- Linked List bana sakta hoon
- Copy kar sakta hoon
- Delete safely kar sakta hoon
*/

int main()
{
    myLinkedList list1;

    list1.insertAtLast(10);
    list1.insertAtLast(20);
    list1.insertAtLast(30);

    cout << "Original List:\n";
    list1.display();

    // Copy constructor test
    myLinkedList list2 = list1;

    cout << "Copied List:\n";
    list2.display();

    // Remove test
    list1.removeFromFirst();
    cout << "After removing from first:\n";
    list1.display();

    list1.removeFromLast();
    cout << "After removing from last:\n";
    list1.display();

    return 0;
}