#include <iostream>
#include "myLinkedList.h"
using namespace std;

int main()
{
    myLinkedList list;
    cout << "=== Insert 5,1,4,2,3 ===\\n";
    list.insertAtLast(5); list.insertAtLast(1); list.insertAtLast(4);
    list.insertAtLast(2); list.insertAtLast(3);
    list.display();  

    cout << "\\n=== put(9, 1) ===\\n";
    list.put(9, 1); list.display();  

    cout << "\\n=== swap(0,4) ===\\n";
    list.swap(0, 4); list.display();  

    cout << "\\n=== sort(true) ===\\n";
    list.sort(true); list.display();  

    cout << "\\n=== sort(false) ===\\n";
    list.sort(false); list.display();  

    return 0;
}