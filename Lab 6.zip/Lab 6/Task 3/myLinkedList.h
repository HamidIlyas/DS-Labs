﻿#pragma once
#include <iostream>
#include "LinkedList.h"
using namespace std;

class myLinkedList : public LinkedList {
public:
    void insertAtLast(int value);
    void insertAtFirst(int value);
    void display();
    int removeFromFirst();
    int removeFromLast();
    bool isEmpty();
    int getSize();
    bool search(int v);
    int peek(int pos);
    int get(int pos);
    void put(int v, int pos);
    void swap(int xi, int yi);
    void sort(bool asc);
};

bool myLinkedList::isEmpty() {
    return first == nullptr && last == nullptr;
}

int myLinkedList::removeFromLast() {
    if (first == nullptr && last == nullptr) {
        cout << "LL is empty; returning NULL value" << endl;
        return -99999;
    }
    else if (first == last) {
        int returningValue = first->data;
        delete last;
        first = nullptr;
        last = nullptr;
        return returningValue;
    }
    else {
        Node* t = first;
        while (1) {
            if (t->next == last) {
                break;
            }
            t = t->next;
        }
        int returningValue = last->data;
        delete last;
        t->next = nullptr;
        last = t;
        return returningValue;
    }
}

int myLinkedList::removeFromFirst() {
    if (first == nullptr && last == nullptr) {
        cout << "LL is empty; returning NULL value" << endl;
        return -99999;
    }
    else if (first == last) {
        int returningValue = first->data;
        delete last;
        first = nullptr;
        last = nullptr;
        return returningValue;
    }
    else {
        int returningValue = first->data;
        Node* t = first;
        first = first->next;
        delete t;
        t = nullptr;
        return returningValue;
    }
}

void myLinkedList::display() {
    if (first == nullptr && last == nullptr) {
        cout << "->\n";
        return;
    }
    Node* t = first;
    while (1) {
        cout << t->data << " -> ";
        t = t->next;
        if (t == nullptr) {
            break;
        }
    }
    cout << endl;
}

void myLinkedList::insertAtFirst(int value) {
    Node* nn = new Node;
    nn->data = value;
    nn->next = nullptr;
    if (first == nullptr && last == nullptr) {
        first = nn;
        last = nn;
    }
    else {
        nn->next = first;
        first = nn;
    }
}

void myLinkedList::insertAtLast(int value) {
    Node* nn = new Node;
    nn->data = value;
    nn->next = nullptr;
    if (first == nullptr && last == nullptr) {
        first = nn;
        last = nn;
    }
    else {
        last->next = nn;
        last = nn;
    }
}

int myLinkedList::getSize() {
    int size = 0;
    Node* t = first;
    while (t != nullptr) {
        size++;
        t = t->next;
    }
    return size;
}

bool myLinkedList::search(int v) {
    Node* t = first;
    while (t != nullptr) {
        if (t->data == v) return true;
        t = t->next;
    }
    return false;
}

int myLinkedList::peek(int pos) {
    if (pos < 0) {
        cout << "Invalid position" << endl;
        return -99999;
    }
    Node* t = first;
    int index = 0;
    while (t != nullptr && index < pos) {
        t = t->next;
        index++;
    }
    if (t == nullptr) {
        cout << "Position out of bounds" << endl;
        return -99999;
    }
    return t->data;
}

int myLinkedList::get(int pos) {
    if (pos < 0) {
        cout << "Invalid position" << endl;
        return -99999;
    }
    if (first == nullptr && last == nullptr) {
        cout << "LL is empty" << endl;
        return -99999;
    }
    if (pos == 0) return removeFromFirst();

    Node* t = first;
    int index = 0;
    while (t != nullptr && index < pos - 1) {
        t = t->next;
        index++;
    }
    if (t == nullptr || t->next == nullptr) {
        cout << "Position out of bounds" << endl;
        return -99999;
    }

    Node* target = t->next;
    int retValue = target->data;
    t->next = target->next;
    if (target == last) last = t;
    delete target;
    return retValue;
}

void myLinkedList::put(int v, int pos) {
    if (pos < 0) {
        cout << "Invalid position" << endl;
        return;
    }
    if (first == nullptr && last == nullptr) {
        if (pos == 0) insertAtLast(v);
        else cout << "Empty list" << endl;
        return;
    }
    if (pos == 0) {
        insertAtFirst(v);
        return;
    }

    Node* t = first;
    int index = 0;
    while (t != nullptr && index < pos - 1) {
        t = t->next;
        index++;
    }
    if (t == nullptr || t->next == nullptr) {
        cout << "Position out of bounds" << endl;
        return;
    }

    Node* newNode = new Node;
    newNode->data = v;
    newNode->next = t->next;
    t->next = newNode;
    if (newNode->next == nullptr) last = newNode;
}

void myLinkedList::swap(int xi, int yi) {
    if (xi < 0 || yi < 0 || xi == yi) {
        cout << "Invalid positions" << endl;
        return;
    }

    Node* prevX = nullptr, * currX = first;
    int i = 0;
    while (currX != nullptr && i < xi) {
        prevX = currX;
        currX = currX->next;
        i++;
    }
    if (currX == nullptr) {
        cout << "Position " << xi << " out of bounds" << endl;
        return;
    }

    Node* prevY = nullptr, * currY = first;
    i = 0;
    while (currY != nullptr && i < yi) {
        prevY = currY;
        currY = currY->next;
        i++;
    }
    if (currY == nullptr) {
        cout << "Position " << yi << " out of bounds" << endl;
        return;
    }

    int tempVal = currX->data;
    currX->data = currY->data;
    currY->data = tempVal;
}

void myLinkedList::sort(bool asc) {
    if (first == nullptr || first == last) return;

    bool swapped;
    do {
        swapped = false;
        Node* t = first;
        while (t->next != nullptr) {
            if ((asc && t->data > t->next->data) || (!asc && t->data < t->next->data)) {
                int temp = t->data;
                t->data = t->next->data;
                t->next->data = temp;
                swapped = true;
            }
            t = t->next;
        }
    } while (swapped);
}