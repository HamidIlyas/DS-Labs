﻿#include <iostream>
#include "LinkedList.h"
using namespace std;

class myLinkedList : public LinkedList
{
public:
    void insertAtLast(int value);
    void insertAtFirst(int value);
    void display();
    int removeFromFirst();
    int removeFromLast();
    bool isEmpty();

    int getSize() {
        int size = 0;
        Node* t = first;
        while (t != nullptr) {
            size++;
            t = t->next;
        }
        return size;
    }

    bool search(int v) {
        Node* t = first;
        while (t != nullptr) {
            if (t->data == v) return true;
            t = t->next;
        }
        return false;
    }

    int peek(int pos) {
        if (pos < 0) {
            cout << "Invalid position" << endl;
            return -99999;
        }
        Node* t = first;
        int index = 0;
        while (t != nullptr && index < pos) {
            t = t->next;
            index++;
        }
        if (t == nullptr) {
            cout << "Position out of bounds" << endl;
            return -99999;
        }
        return t->data;
    }

    int get(int pos) {
        if (pos < 0) {
            cout << "Invalid position" << endl;
            return -99999;
        }
        if (first == nullptr && last == nullptr) {
            cout << "LL is empty" << endl;
            return -99999;
        }
        if (pos == 0) return removeFromFirst();

        Node* t = first;
        int index = 0;
        while (t != nullptr && index < pos - 1) {
            t = t->next;
            index++;
        }
        if (t == nullptr || t->next == nullptr) {
            cout << "Position out of bounds" << endl;
            return -99999;
        }

        Node* target = t->next;
        int retValue = target->data;
        t->next = target->next;
        if (target == last) last = t;
        delete target;
        return retValue;
    }
};
bool myLinkedList::isEmpty() {
    return first == nullptr && last == nullptr;
}

int myLinkedList::removeFromLast() {
    if (first == nullptr && last == nullptr) {
        cout << "LL is empty; returning NULL value" << endl;
        return -99999;
    }
    else if (first == last) {
        int returningValue = first->data;
        delete last;
        first = nullptr;
        last = nullptr;
        return returningValue;
    }
    else {
        Node* t = first;
        while (1) {
            if (t->next == last) break;
            t = t->next;
        }
        int returningValue = last->data;
        delete last;
        t->next = nullptr;
        last = t;
        return returningValue;
    }
}

int myLinkedList::removeFromFirst() {
    if (first == nullptr && last == nullptr) {
        cout << "LL is empty; returning NULL value" << endl;
        return -99999;
    }
    else if (first == last) {
        int returningValue = first->data;
        delete last;
        first = nullptr;
        last = nullptr;
        return returningValue;
    }
    else {
        int returningValue = first->data;
        Node* t = first;
        first = first->next;
        delete t;
        t = nullptr;
        return returningValue;
    }
}

void myLinkedList::display() {
    if (first == nullptr && last == nullptr) {
        cout << "->\\n";
        return;
    }
    Node* t = first;
    while (1) {
        cout << t->data << " -> ";
        t = t->next;
        if (t == nullptr) break;
    }
    cout << endl;
}

void myLinkedList::insertAtFirst(int value) {
    Node* nn = new Node;
    nn->data = value;
    nn->next = nullptr;
    if (first == nullptr && last == nullptr) {
        first = nn;
        last = nn;
    }
    else {
        nn->next = first;
        first = nn;
    }
}

void myLinkedList::insertAtLast(int value) {
    Node* nn = new Node;
    nn->data = value;
    nn->next = nullptr;
    if (first == nullptr && last == nullptr) {
        first = nn;
        last = nn;
    }
    else {
        last->next = nn;
        last = nn;
    }
}