#include <iostream>
#include "myLinkedList.h"
using namespace std;

int main()
{
    myLinkedList list;
    cout << "Inserting 10,20,30,40,50\\n";
    list.insertAtLast(10); list.insertAtLast(20);
    list.insertAtLast(30); list.insertAtLast(40); list.insertAtLast(50);
    list.display();

    cout << "Size: " << list.getSize() << endl;
    cout << "Search 30: " << (list.search(30) ? "Found" : "Not found") << endl;
    cout << "Peek(2): " << list.peek(2) << endl;

    cout << "\\nget(1): " << list.get(1) << endl; list.display();
    cout << "get(0): " << list.get(0) << endl; list.display();
    cout << "Final size: " << list.getSize() << endl;

    return 0;
}